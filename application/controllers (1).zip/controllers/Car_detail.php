<?php

class Car_detail extends CI_Controller
{
     function __construct() {
        parent::__construct();
        
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        if(!$this->ion_auth->logged_in())
        {
            redirect('auth');
        }
        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->load->model('Car_detail_model');
        
    }
    
    public function index() {
        $this->data['title'] = 'Car Details';
        $this->data['result'] = $this->Car_detail_model->car_detail();
        $this->load->view('car/index',$this->data);
    }

    public function edit($id = NULL){

    }
}